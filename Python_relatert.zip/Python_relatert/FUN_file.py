#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr 19 21:30:54 2021

@author: trondkjekstad
"""

from flask import Flask,render_template

app=Flask(__name__,template_folder='templates')

@app.route('/home')
@app.route('/')

def FUN_file():
    return render_template('FUN_file.html')


if __name__== '__main__':
    app.run(debug=True)
    
    