#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr 19 11:38:52 2021

@author: trondkjekstad
"""


from flask import( Flask , render_template, url_for , redirect , request   )

# Important to save everything the right way, remember to import the right folder 
app=Flask(__name__,template_folder='templates')

@app.route('/home/')
@app.route('/')

def home():
    return render_template('home.html')

@app.route('/map_screen/')
def map_screen():
    return render_template('map.html')

@app.route('/work_space/')
def work_space():
    return render_template('work_space.html')

   
@app.route('/login/', methods=['POST','GET'])
def login():
    if request.method == 'POST':
        user=request.form['nm']
        return redirect(url_for( "user" , usr=user ))
    else:
        return render_template('login.html')



@app.route('/<usr>/')
def user(usr):
    return f"<h1> {usr} </h1>"
    


if __name__ == '__main__':
    app.run(debug=True)
    
    
