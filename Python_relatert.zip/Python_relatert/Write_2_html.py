#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr 19 11:31:25 2021

@author: trondkjekstad
"""

file=open('login.html','w')
file.write=('hei')
file.close()

