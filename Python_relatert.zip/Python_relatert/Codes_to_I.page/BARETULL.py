#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu May  6 14:56:24 2021

@author: trondkjekstad
"""

## TULLBALL
import pandas as pd
mm=pd.read_csv('length_matrix.csv',)



print(mm.iloc[1,6])
print(mm.iloc[2,6])
print(mm.iloc[3,6])
print(mm.iloc[4,6],'4 og 5')
print(mm.iloc[6,6])

# print(mm.iloc[0,2])
# print(mm.iloc[0,3])
# print(mm.iloc[0,4])
# print(mm.iloc[0,5])
# print(mm.iloc[0,6])
# print(mm.iloc[0,7],'\n')

# print(mm.iloc[1,3])
# print(mm.iloc[1,4])
# print(mm.iloc[1,5])
# print(mm.iloc[1,6])
# print(mm.iloc[1,7],'\n')


# print(mm.iloc[2,4])
# print(mm.iloc[2,5])
# print(mm.iloc[2,6])
# print(mm.iloc[2,7],'\n')






